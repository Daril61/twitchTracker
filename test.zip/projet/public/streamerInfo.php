<?php
$url = "http://185.157.246.102/projet/";

include __DIR__ . '/../view/streamerInfo.php';


?>